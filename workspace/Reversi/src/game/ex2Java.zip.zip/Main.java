package pack;
/*
 * Naama Harshoshanim
 * 315783217
 * Tchelet Englman
 * 208780585
 */

public class Main {
	Board board = new BoardConsole(8);
    PersonP personP1 = new PersonP("X" ,Black);
    PersonP personP2 = new PersonP("O" ,White);
    Logic standartLogic = new StandartLogic(board);
    Game game(board, standartLogic, personP1, personP2);
    game.run();
    return 0;
}
