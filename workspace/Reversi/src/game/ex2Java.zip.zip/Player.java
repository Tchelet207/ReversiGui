package pack;

import java.util.ArrayList;
import pack.Board.celltype;

public interface Player {
	/**
     * choosing cell from the vector of the optional cells.
     * @param options
     * @return Point
     */
	Point chooseCell(ArrayList<Point> options);
	/**
     * get the member cellType1.
     * @return cellType
     */
    celltype getCellType();
    /**
     * get the member name.
     * @return string
     */
    String getName();
}