package pack;
/*
 * Naama Harshoshanim
 * 315783217
 * Tchelet Englman
 * 208780585
 */
public interface Board {
	enum celltype {Black, White, Empty};
	/*
     * destructor.
     */
    ~Board();
    /*
     * printing the board. abstruct.
     */
	void printBoard();
    /**
     * checking if the board is full. abstruct.
     * @return bool
     */
    boolean ifFull();
    /**
     * checking who wins. abstruct.
     * @return cellType
     */
    celltype whoWins();
    /**
     * returning the board.
     * @return cellType**
     */
    celltype** getBoard();
    /**
     * returning the size.
     * @return int
     */
    int getSize();
}
