package pack;

import java.util.ArrayList;

import pack.Board.celltype;

public class PersonP implements Player {
	//members:
	private String name;
	private celltype celltype1;

	/**
	 * constructor.
	 */
	public PersonP(String name, celltype celltype) {
	    this.name = name;
	    this.celltype1 = celltype;
	}
	/**
	 * choose cell.
	 * @param options array of option
	 */
	public Point chooseCell(ArrayList<Point> options) {
	    //cout << name << ": its your move." << endl;
	    //cout << "Your possible moves: ";
	    for (int i = 0; i < options.size(); i++) {
	        //cout << "(" << options->at(i).getX() << ","
	        //     << options->at(i).getY() << ") ";
	    }
	    //cout << endl << endl;
	    //cout << "Please enter your move row col:" << endl;
	    int x = 0, y = 0;
	    //cin >> x >> y;
	    //if (cin.fail()) {
	    //    cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); //skip bad input
	    //}
	    // user didn't input a number
	    //cout << "Please enter numbers only." << endl;
	    //cin.clear(); // reset failbit
	    //cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); //skip bad input
	    Point cell = new Point(x,y);
	    return cell;
	}
	/**
	 * return the celltype
	 * @return celltype
	 */
	public celltype getCellType() {
	    return this.celltype1;
	}
	/**
	 * return the name
	 * @return name
	 */
	public String getName() {
		return this.name;
	}
	
}