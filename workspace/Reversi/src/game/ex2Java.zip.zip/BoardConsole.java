package pack;
/*
 * Naama Harshoshanim
 * 315783217
 * Tchelet Englman
 * 208780585
 */
public class BoardConsole implements Board {
	private int size;
    private celltype** board;
    /**
     * constructor.
     * @param size
     */
    public BoardConsole(int size) {
	    this.size = size;
	    this.board = new celltype*[size];
	    for (int i=0; i<size; i++) {
	        this.board[i] = new celltype[size];
	    }
	    for (int i=0; i<size; i++) {
	        for (int j=0; j<size; j++) {
	            this.board[i][j] = Empty;
	        }
	    }
	    this.board[(size/2)-1][(size/2)-1] = White;
	    this.board[size/2][size/2] = White;
	    this.board[(size/2)-1][size/2] = Black;
	    this.board[size/2][(size/2)-1] = Black;
	}
    
    public BoardConsole() {
    	this.size = 8;
        this.board = new celltype*[this->size];
        for (int i=0; i<this.size; i++) {
            this.board[i] = new celltype[this.size];
        }
        for (int i=0; i<this.size; i++) {
            for (int j=0; j<this.size; j++) {
                this.board[i][j] = Empty;
            }
        }
        this.board[(this.size/2)-1][(this.size/2)-1] = White;
        this.board[this.size/2][this.size/2] = White;
        this.board[(this.size/2)-1][this.size/2] = Black;
        this.board[this.size/2][(this.size/2)-1] = Black;
    }
    /**
     * destructor.
     */
    public ~BoardConsole() {
        for (int i=0; i<this->size; i++) {
            delete[] this->board[i];
        }
        delete[] this->board;
    }
    /**
     * return the board.
     * @return cellType**
     */
    @Override
	public celltype** getBoard() {
	    return this.board;
	}

    /**
     * printing the board.
     */
	@Override
	public void printBoard() {
		System.out.print(" |");
	    for (int i=1; i<size+1; i++) {
			System.out.print(" ");
			System.out.print(i);
			System.out.print(" |");
	    }
		System.out.println("");
	    for (int i=0; i<(size*4)+2; i++) {
	    	System.out.print("-");
	    }
		System.out.println("");
	    for (int i=0; i<size; i++) {
			System.out.print(i + 1);
			System.out.print("|");
	        for (int j=0; j<size; j++) {
	            if(board[i][j] == Black) {
		            System.out.print(" X |");
	            } else if (board[i][j] == White) {
	            	System.out.print(" O |");
	            } else {
	            	System.out.print("   |");
	            }
	        }
			System.out.println("");
	        for (int m=0; m<(size*4)+2; m++) {
		    	System.out.print("-");
	        }
			System.out.println("");
	    }		
	}
	
	/**
     * checking if the board is full.
     * @return boolean
     */
	@Override
	public boolean ifFull() {
		boolean empty = false;
	    for (int i = 0; i < this.size; i++) {
	        for (int j = 0; j < this.size; j++) {
	            if (this.board[i][j] == Empty) {
	                empty = true;
	            }
	        }
	    }
	    return !empty;
	}

	/**
     * checking who wins.
     * @Override
     * @return cellType
     */
	public celltype whoWins() {
		int blackC = 0, whiteC = 0;
	    for (int i = 0; i < this.size; i++) {
	        for (int j = 0; j < this.size; j++) {
	            if (this.board[i][j] == White) {
	                whiteC++;
	            } else if (this.board[i][j] == Black) {
	                blackC++;
	            }
	        }
	    }
	    if (blackC > whiteC) {
	        return Black;
	    } else if (whiteC > blackC) {
	        return White;
	    }
	    return Empty;
	}

	/**
     * return the size.
     * @return size
     * @Override
     */
	public int getSize() {
		return this.size;
	}
}